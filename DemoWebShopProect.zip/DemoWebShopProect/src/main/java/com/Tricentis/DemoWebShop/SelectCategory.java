package com.Tricentis.DemoWebShop;


import java.sql.Driver;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import junit.framework.Assert;

public class SelectCategory{

	static double price;
	static int quantity = 2;
	@FindBy(xpath="//div[@class='header-menu']/ul[@class='top-menu']/li/a[contains(text(),'Books')]")
	static
	WebElement books;
	@FindBy(xpath="//div[@class='product-price']/span")
	static
	WebElement productPrice;
	@FindBy(xpath="//div[@class='add-to-cart']/div/input[@class='qty-input']")
	static
	WebElement quantityInput;
	@FindBy(xpath="//input[@id='add-to-cart-button-45']")
	static
	WebElement addToCart;
	@FindBy(xpath="//span[@class='close']/following::p[@class='content']")
	static
	WebElement addCartSuccessMessage;
	@FindBy(xpath="//td/span[text()='Sub-Total:']/../../td[2]/span/span[@class='product-price']")
	static
	WebElement total;
	@FindBy(xpath="//input[@id='termsofservice']")
	static
	WebElement termOfService;
	@FindBy(xpath="//button[@id='checkout']")
	static
	WebElement checkOut;
	@FindBy(xpath="//div[@class='page-body']/div[3]")
	List<WebElement> element;
	@FindBy(xpath="//a/span[text()='Shopping cart']")
	WebElement shoppingCart;
	
	
	/*1) In this method i am selecting Book Category and getting the price of the selected Book.
	  2) I have entered the quantity more than one
	  3) I have added the Select Book to the Card
	  4) I have validated the message displayed after adding to the cart*/
	
	public void selectBook(){
	books.click();
	element.get(0).click();
	String priceText = productPrice.getText().toString();
	String qty = Integer.toString(quantity);
	quantityInput.clear();
	quantityInput.sendKeys(qty);
	addToCart.click();
	String expectedMessage = "The product has been added to your shopping cart";
	String actualMessage = addCartSuccessMessage.getText();
	Assert.assertEquals(expectedMessage, actualMessage);
	shoppingCart.click();
	price = Double.parseDouble(priceText);  
	}
	
	/*1) In this method I have calculated the Sub Total by the Price and Quantity 
	  2) After Calculating I have Validated the expected and actual sub totals
	  3) In this method i am navigating to the Confirm Order class to place the order*/
	
	public void validateSubTotal(){
		double expectedSubtotal = price * quantity;
		double actualSubtotal;
		String subTotal = total.getText().toString();
		actualSubtotal = Double.parseDouble(subTotal);
		Assert.assertEquals(expectedSubtotal, actualSubtotal);
		termOfService.click();
		checkOut.click();
	}
	
	 
}
