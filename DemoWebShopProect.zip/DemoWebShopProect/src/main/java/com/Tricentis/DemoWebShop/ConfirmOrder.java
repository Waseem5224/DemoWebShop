package com.Tricentis.DemoWebShop;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class ConfirmOrder extends SelectCategory{

	@FindBy(xpath="//select[@id = 'billing-address-select']")
	static
	WebElement billingDropDown;
	@FindBy(xpath="//input[@id = 'BillingNewAddress_FirstName']")
	static
	WebElement firstNameInput;
	@FindBy(xpath="//input[@id = 'BillingNewAddress_LastName']")
	static
	WebElement lastNameInput;
	@FindBy(xpath="//select[@id = 'BillingNewAddress_CountryId']")
	static
	WebElement countrydropdown;
	@FindBy(xpath="//input[@id = 'BillingNewAddress_City']")
	static
	WebElement cityField;
	@FindBy(xpath="//input[@id = 'BillingNewAddress_Address1']")
	static
	WebElement addressField;
	@FindBy(xpath="//input[@id = 'BillingNewAddress_ZipPostalCode']")
	static
	WebElement postalCodeField;
	@FindBy(xpath="//input[@id = 'BillingNewAddress_PhoneNumber']")
	static
	WebElement phoneNumberField;
	@FindBy(xpath="//div[@id = 'billing-buttons-container']/input[@title='Continue']")
	static
	WebElement billingContinueBtn;
	@FindBy(xpath="//select[@id = 'shipping-address-select']")
	static
	WebElement shippingDropDown;
	@FindBy(xpath="//div[@id = 'shipping-buttons-container']/input[@title='Continue']")
	static
	WebElement shippingContinueBtn;
	@FindBy(xpath="//label[text() = 'Next Day Air (40.00)']/../input[@id = 'shippingoption_1']")
	static
	WebElement nextDayAirRadioBtn;
	@FindBy(xpath="//label[text() = 'Ground (10.00)']/../input[@id = 'shippingoption_0']]")
	static
	WebElement groundRadioBtn;
	@FindBy(xpath="//label[text() = '2nd Day Air (20.00)']/../input[@id = 'shippingoption_2']")
	static
	WebElement secondDayAirRadioBtn;
	@FindBy(xpath="//div[@id = 'shipping-method-buttons-container']//input[@class='button-1 shipping-method-next-step-button']")
	static
	WebElement shippingMethodContinueBtn;
	@FindBy(xpath="//label[text()='Cash On Delivery (COD) (7.00)']/../input[@id='paymentmethod_0']")
	static
	WebElement codRadionbtn;
	@FindBy(xpath="//div[@id = 'payment-method-buttons-container']//input[@class='button-1 payment-method-next-step-button']")
	static
	WebElement paymentMethodContinueBtn;
	@FindBy(xpath="//label[text()='Check / Money Order (5.00)']/../input[@id='paymentmethod_1']")
	static
	WebElement checkMoneyOrderRadioBtn;
	@FindBy(xpath="//label[text()='Credit Card']/../input[@id='paymentmethod_2']")
	static
	WebElement creditCardRadioBtn;
	@FindBy(xpath="//label[text()='Purchase Order']/../input[@id='paymentmethod_3']")
	static
	WebElement purchaseOrderRadiobtn;
	@FindBy(xpath="//tr/td/p")
	static
	WebElement paymentInfo;
	@FindBy(xpath="//div[@id = 'payment-info-buttons-container']//input[@class='button-1 payment-info-next-step-button']")
	static
	WebElement paymentInfoContinueBtn;
	@FindBy(xpath="//div[@id = 'confirm-order-buttons-container']//input[@class='button-1 confirm-order-next-step-button']")
	static
	WebElement confirmOrder;
	@FindBy(xpath="//div[@class='title']/strong")
	static
	WebElement successMessage;
	@FindBy(xpath="//ul[@class='details']/li")
	static
	WebElement orderId;
	@FindBy(xpath="//input[@class='button-2 order-completed-continue-button']")
	static
	WebElement confirmContinueBtn;
	//input[@class='button-2 order-completed-continue-button']
	
	/*1) In this method i am entering the billing address details.
	  2) Also navigating to the Shipping Address method*/
	
	public void billingAddress(String firstName, String lastName, String city, String address, String postalCode, String phoneNumber, String country,String shippingMethod,String paymentMethod){
		Select select = new Select(billingDropDown);
		select.selectByVisibleText("New Address");
		firstNameInput.clear();
		firstNameInput.sendKeys(firstName);
		lastNameInput.clear();
		lastNameInput.sendKeys(lastName);
		Select selectCountry = new Select(countrydropdown);
		selectCountry.selectByVisibleText(country);
		cityField.sendKeys(city);
		addressField.sendKeys(address);
		postalCodeField.sendKeys(postalCode);
		phoneNumberField.sendKeys(phoneNumber);
		billingContinueBtn.click();
		shippingAddress(firstName,lastName,city,address,postalCode,phoneNumber,country,shippingMethod,paymentMethod);
	}
	
	/*1) In this method i am selecting Shipping address same as the billing address.
	  2) Also navigating to the Shipping Method*/
	
	public static void shippingAddress(String firstName, String lastName, String city, String address, String postalCode, String phoneNumber, String country,String shippingMethod,String paymentMethod){
		Select select = new Select(shippingDropDown);
		String shippingAddress = firstName + " " +lastName+ ","+ " " +address+ ","+ " " +city+ " "+postalCode+ ","+ " " +country;
		select.selectByVisibleText(shippingAddress);
		shippingContinueBtn.click();
		shippingMethod(shippingMethod,paymentMethod);
	}
	
	/*1) In this method i am selecting shipping method as Next Day Air.
	  2) Also navigating to the Payment Method*/
	
	public static void shippingMethod(String shippingMethod, String paymentMethod){
		if(shippingMethod.equalsIgnoreCase("Next Day Air")){
			nextDayAirRadioBtn.click();
		}
		else if(shippingMethod.equalsIgnoreCase("Ground")){
			groundRadioBtn.click();
		}
		else if(shippingMethod.equalsIgnoreCase("2nd Day Air"))
		{
			secondDayAirRadioBtn.click();
		}
		else{
			System.out.println("Invalid Shipping Method");
		}
		shippingMethodContinueBtn.click();
		 paymentMethod(paymentMethod);
	}
	
	/*1) In this method i am selecting payment method as Cash On Delivery.
	  2) Also navigating to the Payment Information Method*/
	
	public static void paymentMethod(String paymentMethod){
		  
		if(paymentMethod.equalsIgnoreCase("Cash On Delivery")){
			if(codRadionbtn.isSelected()){
				paymentMethodContinueBtn.click();
			}
			else{
				codRadionbtn.click();
				paymentMethodContinueBtn.click();
			}
		}
		else if(paymentMethod.equalsIgnoreCase("Check / Money Order")){
			if(checkMoneyOrderRadioBtn.isSelected()){
				paymentMethodContinueBtn.click();
			}
			else{
				checkMoneyOrderRadioBtn.click();
				paymentMethodContinueBtn.click();
			}
		}
		else if(paymentMethod.equalsIgnoreCase("Credit Card")){
			if(creditCardRadioBtn.isSelected()){
				paymentMethodContinueBtn.click();
			}
			else{
				creditCardRadioBtn.click();
				paymentMethodContinueBtn.click();
			}
		}
		else if(paymentMethod.equalsIgnoreCase("Purchase Order")){
			if(purchaseOrderRadiobtn.isSelected()){
				paymentMethodContinueBtn.click();
			}
			else{
				purchaseOrderRadiobtn.click();
				paymentMethodContinueBtn.click();
			}
		}
		else{
			System.out.println("Invalid Payment Method");
		}
			paymentInformation();	
	}
	
	/*1) In this method i am Validating the payment information text displayed after selecting payment method as Cash On Delivery.
	  2) Also navigating to the Confirm Method*/
	
	public static void paymentInformation(){
		String expectedPaymentInfo = "You will pay by COD";
		String actualPaymentInfo = paymentInfo.getText().toString();
		if(expectedPaymentInfo.equalsIgnoreCase(actualPaymentInfo)){
			paymentInfoContinueBtn.click();
		}
		else{
			System.out.println("Invalid Payment Information");
		}
			confirm();
		}
	
	/*1) In this method i am confirming the order and printing the order number
	  2) Also Navigating to home page to logout the application*/ 
	   
	public static void confirm(){
		confirmOrder.click();
		String expectedSuccessMessage = "Your order has been successfully processed!";
		String actualSuccessMessage = successMessage.getText().toString();
		if(expectedSuccessMessage.equalsIgnoreCase(actualSuccessMessage)){
			String orderNumber = orderId.getText().toString();
			String separator =":";
		      int sepPos = orderNumber.indexOf(separator);
		      if (sepPos == -1) {
		         System.out.println("");
		      }
		      System.out.println("Order Number is = "+orderNumber.substring(sepPos +       separator.length()));
		   
		}
		confirmContinueBtn.click();
	}
	}

