package com.Tricentis.DemoWebShop;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import Util.TestUtil;
import junit.framework.Assert;

public class Login{
	
/*Here I am declaring all the Webelements */
	
	@FindBy(xpath="//a[text()='Log in']")
	WebElement logIn;
	@FindBy(xpath="//div[@class = 'page-title']/h1")
	WebElement title;
	@FindBy(xpath="//input[@id='Email']")
	WebElement userId;
	@FindBy(xpath="//input[@id='Password']")
	WebElement passwordId;
	@FindBy(xpath="//input[@value = 'Log in']")
	WebElement loginButton;
	@FindBy(xpath="//a[text()='atest@gmail.com']")
	WebElement accountId;
	@FindBy(xpath="//a/span[@class='cart-qty']")
	static
	WebElement shoppingCartQuantity;
	@FindBy(xpath="//a/span[text()='Shopping cart']")
	WebElement shoppingCart;
	@FindBy(xpath="//tr[@class='cart-item-row']/td[@class='remove-from-cart']")
	static
	WebElement removeFromCart;
	@FindBy(xpath="//input[@value='Update shopping cart']")
	static
	WebElement updateShoppingCart;
	@FindBy(xpath="//a[text()='Log out']")
	WebElement logout;
	 
	/*Here I am login to the application by using the test data like Username and Password.
	  Also validating the Account Id of the user*/
	
	public void login(String username, String password){
		logIn.click();
		String expectedText = "Welcome, Please Sign In!";
		String actualText = title.getText();
		Assert.assertEquals(expectedText, actualText);
		userId.sendKeys(username);
		passwordId.sendKeys(password);
		loginButton.click();
		String actualAccountId = accountId.getText();
		Assert.assertEquals(username, actualAccountId);
	}
	
	/*In this method i am clearing the Shopping Cart if anything are added.*/
	
	public void shoppingCart(){
		String cartQty = shoppingCartQuantity.getText().toString();
		String cartQuantity = cartQty.substring(1,cartQty.length()-1);
		int quantity = Integer.parseInt(cartQuantity);
		if(quantity!=0){
			shoppingCart.click();
			removeFromCart.click();
			updateShoppingCart.click();
		}
	}
	
	/*Here I am Performing Logout action*/
	
	public void logout() {
		logout.click();
	}

}
