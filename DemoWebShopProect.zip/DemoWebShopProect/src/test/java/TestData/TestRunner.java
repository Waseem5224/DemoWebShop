package TestData;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.Tricentis.DemoWebShop.ConfirmOrder;
import com.Tricentis.DemoWebShop.Login;
import com.Tricentis.DemoWebShop.SelectCategory;

import Util.TestUtil;

public class TestRunner {
	public static WebDriver driver;
	/*In this i have initialized the Webdriver and open the given Url */
	
	@SuppressWarnings("deprecation")
	@BeforeMethod
	public void setup() {
		System.setProperty("webdriver.chrome.driver","C:\\Chrome Driver\\chromedriver.exe");
		/* Initializing  the Chrome Driver*/
		driver = new ChromeDriver();
		PageFactory.initElements(driver, this);
		driver.manage().deleteAllCookies();
		/* Maximizing the browser*/
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		/* Opening the URL*/
		driver.get("http://demowebshop.tricentis.com/");
	}
	
	/*1) Here I am passing the Sheet name to load the test data from Test Utill class
	  2) Using Data Providers of TestNG */
	
	@DataProvider
	public Object[][] getData(){
		Object[][] data = TestUtil.getTestData("Sheet2");
		return data;
	}
	
	@Test(dataProvider= "getData")
	public void validateShoppingCart(String username, String password,String firstName, String lastName, String city, String address, String postalCode, String phoneNumber, String country,String shippingMethod,String paymentMethod,String selectCategory){
		Login login = PageFactory.initElements(driver, Login.class);
		login.login(username, password);
	    login.shoppingCart();
	    SelectCategory category = PageFactory.initElements(driver, SelectCategory.class);
	    category.selectBook();
	    category.validateSubTotal();
	    ConfirmOrder confirmOrder = PageFactory.initElements(driver, ConfirmOrder.class);
	    confirmOrder.billingAddress(firstName, lastName, city, address, postalCode, phoneNumber, country, shippingMethod, paymentMethod);
	}
	
	/*In this method i am doing logout action and closing the browser */
	@AfterMethod
	public void logout() {
		Login login = PageFactory.initElements(driver, Login.class);
		login.logout();
		driver.close();
	}
}
